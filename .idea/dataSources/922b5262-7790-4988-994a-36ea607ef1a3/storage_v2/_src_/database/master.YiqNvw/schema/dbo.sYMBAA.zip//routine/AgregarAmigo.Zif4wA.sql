
CREATE   PROCEDURE [dbo].[AgregarAmigo](@IDEmisor smallint, @IDReceptor smallint)
AS BEGIN
	INSERT INTO UsuarioAmigo VALUES (@IDEmisor, @IDReceptor)
END
go

