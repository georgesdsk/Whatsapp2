CREATE   PROCEDURE AnhadirPersonaAlChat(@IDUsuario smallint, @IDChat smallint)
AS BEGIN
	INSERT INTO ChatUsuario VALUES (@IDUsuario, @IDChat)
END
go

