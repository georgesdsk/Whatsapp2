CREATE   PROCEDURE PR_AgregarSolicitud(@IDEmisor smallint, @IDReceptor smallint)
AS BEGIN
	INSERT INTO Solicitud VALUES (@IDEmisor, @IDReceptor)
END
go

