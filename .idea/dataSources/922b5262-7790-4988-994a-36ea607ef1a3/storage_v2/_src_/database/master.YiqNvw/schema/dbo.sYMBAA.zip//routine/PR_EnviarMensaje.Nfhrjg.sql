	CREATE   PROCEDURE PR_EnviarMensaje(@Mensaje Varchar(240), @IDChat smallint, @IDUsuario smallint)
	AS BEGIN
		INSERT INTO Mensaje(IDUsuario, Mensaje, IDChat) values (@IDUsuario, @Mensaje, @IDChat ) -- VER SI SE AUTOGENERA EL ID
	END
    go

