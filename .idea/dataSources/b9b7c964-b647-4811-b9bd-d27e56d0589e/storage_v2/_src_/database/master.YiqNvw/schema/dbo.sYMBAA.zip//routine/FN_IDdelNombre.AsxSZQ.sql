CREATE FUNCTION FN_IDdelNombre(@Login VarChar(30))
RETURNS SMALLINT
AS BEGIN RETURN( 
				SELECT ID FROM Usuario
				WHERE @Login = Nombre
					)
END
go

